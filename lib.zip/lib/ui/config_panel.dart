import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/selected_device_provider.dart';
import '../services/config_web_api.dart';
import 'tabs/device_pose_tab.dart';

class ConfigPanel extends ConsumerStatefulWidget {
  const ConfigPanel({super.key});

  @override
  ConsumerState<ConfigPanel> createState() => _ConfigPanelState();
}

class _ConfigPanelState extends ConsumerState<ConfigPanel> {
  final api = const ConfigWebApi(port: 8080);

  final _mqttCtrl = TextEditingController();
  final _locatorCtrl = TextEditingController();
  final _positioningCtrl = TextEditingController();

  bool _loading = false;
  String? _error;
  bool _dirty = false;

  void _setDirty() {
    if (!_dirty) setState(() => _dirty = true);
  }

  @override
  void initState() {
    super.initState();
    _mqttCtrl.addListener(_setDirty);
    _locatorCtrl.addListener(_setDirty);
    _positioningCtrl.addListener(_setDirty);
  }

  @override
  void dispose() {
    _mqttCtrl.dispose();
    _locatorCtrl.dispose();
    _positioningCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final dev = ref.read(selectedDeviceProvider);
    if (dev == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('먼저 장비를 선택하세요.')),
      );
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final m = await api.fetchStagingTexts(ip: dev.ip);

      _mqttCtrl.text = m["mqtt"] ?? "";
      _locatorCtrl.text = m["locator"] ?? "";
      _positioningCtrl.text = m["positioning"] ?? "";

      // 로드 직후 dirty false로 리셋
      setState(() => _dirty = false);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Load 완료 (GET /)')),
      );
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      setState(() => _loading = false);
    }
  }

  /// JSON 문법만 먼저 검증하고 Save
  Future<void> _saveStaging() async {
    final dev = ref.read(selectedDeviceProvider);
    if (dev == null) return;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      // ✅ JSON 문법 체크 (서버로 보내기 전에 앱에서 바로 잡기)
      jsonDecode(_locatorCtrl.text);
      jsonDecode(_positioningCtrl.text);

      await api.saveStagingTexts(
        ip: dev.ip,
        mqtt: _mqttCtrl.text,
        locatorJsonText: _locatorCtrl.text,
        positioningJsonText: _positioningCtrl.text,
      );

      setState(() => _dirty = false);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Save 완료 (POST /save)')),
      );
    } catch (e) {
      setState(() => _error = e.toString());
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Save 실패: $e')),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _apply() async {
    final dev = ref.read(selectedDeviceProvider);
    if (dev == null) return;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      await api.apply(ip: dev.ip);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Apply 완료 (POST /apply)')),
      );
    } catch (e) {
      setState(() => _error = e.toString());
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Apply 실패: $e')),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  Widget _editorCard({
    required String title,
    required String subtitle,
    required TextEditingController controller,
    required double height,
  }) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54)),
              const SizedBox(height: 8),
              SizedBox(
                height: height,
                child: TextField(
                  controller: controller,
                  maxLines: null,
                  expands: true,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  style: const TextStyle(fontFamily: 'Consolas', fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dev = ref.watch(selectedDeviceProvider);

    final selectedLabel = dev == null
        ? '선택된 장비 없음'
        : '${dev.hostname}  (${dev.ip})  /  ${((dev.mac ?? "").isEmpty) ? "MAC:N/A" : dev.mac}';

    return DefaultTabController(
      length: 2,
      child: Card(
        child: Column(
          children: [
            const TabBar(
              tabs: [
                Tab(text: '설정'),
                Tab(text: '좌표'),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  // ==========================
                  // 설정 탭
                  // ==========================
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(selectedLabel, style: Theme.of(context).textTheme.titleSmall),
                        const SizedBox(height: 10),

                        Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          children: [
                            FilledButton.icon(
                              onPressed: (dev == null || _loading) ? null : _load,
                              icon: const Icon(Icons.download),
                              label: Text(_loading ? 'Loading...' : 'Load (GET /)'),
                            ),
                            FilledButton.icon(
                              onPressed: (dev == null || _loading || !_dirty) ? null : _saveStaging,
                              icon: const Icon(Icons.save),
                              label: const Text('Save Staging (POST /save)'),
                            ),
                            FilledButton.icon(
                              onPressed: (dev == null || _loading) ? null : _apply,
                              icon: const Icon(Icons.publish),
                              label: const Text('Apply (POST /apply)'),
                            ),
                            if (_dirty)
                              const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 6, vertical: 10),
                                child: Text('● 수정됨', style: TextStyle(color: Colors.deepOrange)),
                              ),
                          ],
                        ),

                        if (_error != null) ...[
                          const SizedBox(height: 10),
                          Text(_error!, style: const TextStyle(color: Colors.red)),
                        ],

                        const SizedBox(height: 10),

                        Expanded(
                          child: Row(
                            children: [
                              _editorCard(
                                title: 'mqtt_server_setting.txt',
                                subtitle: 'BROKER_HOST 값이 -m MQTT_BROKER_IP로 사용됨',
                                controller: _mqttCtrl,
                                height: 360,
                              ),
                              _editorCard(
                                title: 'locator_config.json (Single)',
                                subtitle: 'JSON 형식 (문법 검사 후 저장)',
                                controller: _locatorCtrl,
                                height: 360,
                              ),
                              _editorCard(
                                title: 'positioning_config.json (Multiple)',
                                subtitle: 'JSON 형식 (문법 검사 후 저장)',
                                controller: _positioningCtrl,
                                height: 360,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ==========================
                  // 좌표 탭
                  // ==========================
                  const DevicePoseTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
