import 'package:http/http.dart' as http;

class ConfigWebApi {
  final int port;
  const ConfigWebApi({this.port = 8080});

  Uri _u(String ip, String path) => Uri.http("$ip:$port", path);

  /// GET / 로 HTML을 받아 textarea(name=mqtt/locator/positioning)를 추출
  Future<Map<String, String>> fetchStagingTexts({required String ip}) async {
    final r = await http
        .get(
      _u(ip, "/"),
      headers: const {
        "Connection": "close",
        "Accept": "text/html",
      },
    )
        .timeout(const Duration(seconds: 12));

    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception("GET / failed: ${r.statusCode} ${r.body}");
    }

    final html = r.body;

    String pick(String name) {
      final startTag = '<textarea name="$name">';
      final i = html.indexOf(startTag);
      if (i < 0) throw Exception("textarea[$name] not found");
      final j = html.indexOf("</textarea>", i);
      if (j < 0) throw Exception("textarea[$name] close tag not found");

      final raw = html.substring(i + startTag.length, j);
      return _htmlUnescape(raw).trim();
    }

    return {
      "mqtt": pick("mqtt"),
      "locator": pick("locator"),
      "positioning": pick("positioning"),
    };
  }


  /// POST /save (폼 전송)
  Future<void> saveStagingTexts({
    required String ip,
    required String mqtt,
    required String locatorJsonText,
    required String positioningJsonText,
  }) async {
    final r = await http
        .post(
      _u(ip, "/save"),
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: {
        "mqtt": mqtt,
        "locator": locatorJsonText,
        "positioning": positioningJsonText,
      },
    )
        .timeout(const Duration(seconds: 10));

    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception("POST /save failed: ${r.statusCode} ${r.body}");
    }
  }

  Future<void> apply({required String ip}) async {
    final r = await http.post(_u(ip, "/apply")).timeout(const Duration(seconds: 8));
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception("POST /apply failed: ${r.statusCode} ${r.body}");
    }
  }

  static String _htmlUnescape(String s) {
    return s
        .replaceAll("&quot;", "\"")
        .replaceAll("&amp;", "&")
        .replaceAll("&lt;", "<")
        .replaceAll("&gt;", ">")
        .replaceAll("&#39;", "'")
        .replaceAll("&nbsp;", " ");
  }
}
